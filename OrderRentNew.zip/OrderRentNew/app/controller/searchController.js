app.controller('searchController',function($scope,$state){
    $scope.OnSearch = function (){
        $state.go('locationOnMap');
    };
});